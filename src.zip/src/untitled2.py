# -*- coding: utf-8 -*-
"""
Created on Fri Jul 16 16:36:11 2021

@author: CK
"""

from PyQt5.QtWidgets import QApplication, QMainWindow, QProgressDialog
import sys
from GUI import Ui_MainWindow
from PyQt5.QtWidgets import QFileDialog
from PyQt5.QtCore import pyqtSignal, Qt
import datetime
import xlwt
#import time
import xlrd
#import numpy as np
#import pandas as pd

from pandas import read_excel,DataFrame,pivot_table
from numpy import sum
from xlutils.copy import copy



class UsingTest(QMainWindow, Ui_MainWindow):
    helpSignal = pyqtSignal(str)
    printSignal = pyqtSignal(list)

    def __init__(self, *args, **kwargs):
        global progress
        super(UsingTest, self).__init__(*args, **kwargs)
        self.setupUi(self)  # 初始化ui
        self.toolButton.clicked.connect(self.openfile_17track)
        self.pushButton.clicked.connect(self.spyder_17track)
        progress.setWindowState(Qt.WindowMaximized)
        progress.setModal(True)
        progress.setWindowState(Qt.WindowActive)
    def openfile_17track(self):
        # directory1 = QFileDialog.getExistingDirectory(self,"选取文件夹","./")   #起始路径
        # print(directory1)
        global fileName1
        fileName1, filetype = QFileDialog.getOpenFileName(self, "选取文件", "./",
                                                          "All Files (*);;Excel Files (*.xls)")  # 设置文件扩展名过滤,注意用双分号间隔
        print(fileName1)
        # print(type(fileName1[0]))
        self.textBrowser.setText(fileName1)
        
    def spyder_17track(self):
#        self.datas = []
#        self.data = xlrd.open_workbook(fileName1, encoding_override='utf-8')
#        global progress
#        progress.setWindowState(Qt.WindowActive)
        self.data = read_excel(fileName1,sheet_name='Raw')
        self.style_percent = xlwt.easyxf(num_format_str ='0%')
        self.df=DataFrame(self.data)


        self.df1 = self.df[['DPP','TAG provider','LT Requested','ROT ','POT','Total ordered quantity']]


        self.df2 = self.df1[self.df1['LT Requested']<7]


        self.df3 =self.df2[self.df2['TAG provider']=='SML']
        self.SML_result1 = self.df3[self.df3['DPP'].isin(['DP China / Guangzhou Xinwei',                                  'DP China / Wuhan Xinwei','DP China / Xiamen',                                    'DP China / Shenzhen','DP Taiwan'])]
        
        self.SML_result2 = self.df3[self.df3['DPP'].isin(['DP China / Shanghai XW',                                    'DP China / Nanjing XW','DP China / Qingdao',                                    'DP China / Tianjin','DP China / Shenzhen','DP Taiwan'])]
        self.df4 =self.df2[self.df2['TAG provider']=='Avery']
        
        self.Avery_result1 = self.df4[self.df4['DPP'].isin(['DP China / Guangzhou Xinwei',                                  'DP China / Xiamen',                                  'DP China / Shenzhen'])]
        self.Avery_result2 = self.df4[self.df4['DPP'].isin(['DP China / Qingdao','DP China / Shanghai XW'                                  'DP China / Nanjing XW','DP China / Tianjin'                                  'DP Taiwan'])]
        
        self.df5 =self.df2[self.df2['TAG provider']=='CheckPoint']
        self.CheckPoint_result = self.df5[self.df5['DPP'].isin(['DP China / Qingdao','DP China / Wuhan Xinwei',                                  'DP China / Shanghai XW','DP China / Nanjing XW',                                  'DP China / Shanghai SP'])]


        self.SML_table1 = pivot_table(self.SML_result1,index=[u"TAG provider"],values=[u'POT',u'ROT ',u'Total ordered quantity'],aggfunc=[sum])
        self.SML_table2 = pivot_table(self.SML_result2,index=[u"TAG provider"],values=[u'POT',u'ROT ',u'Total ordered quantity'],aggfunc=[sum])
        self.Avery_table1 = pivot_table(self.Avery_result1,index=[u"TAG provider"],values=[u'POT',u'ROT ',u'Total ordered quantity'],aggfunc=[sum])
        self.Avery_table2 = pivot_table(self.Avery_result2,index=[u"TAG provider"],values=[u'POT',u'ROT ',u'Total ordered quantity'],aggfunc=[sum])
        self.CheckPoint_table = pivot_table(self.CheckPoint_result,index=[u"TAG provider"],values=[u'POT',u'ROT ',u'Total ordered quantity'],aggfunc=[sum])


        self.data = DataFrame( { 'POT':[ self.SML_table1.loc['SML'].loc['sum'].loc['POT'] , 
                                           self.SML_table2.loc['SML'].loc['sum'].loc['POT'], 
                                           self.Avery_table1.loc['Avery'].loc['sum'].loc['POT'],
                                           self.Avery_table2.loc['Avery'].loc['sum'].loc['POT'], 
                                          self. CheckPoint_table.loc['CheckPoint'].loc['sum'].loc['POT']] , 
                                   'ROT':[ self.SML_table1.loc['SML'].loc['sum'].loc['ROT '] ,                            
                                          self.SML_table2.loc['SML'].loc['sum'].loc['ROT '],                             
                                          self.Avery_table1.loc['Avery'].loc['sum'].loc['ROT '],                           
                                          self.Avery_table2.loc['Avery'].loc['sum'].loc['ROT '],                             
                                          self.CheckPoint_table.loc['CheckPoint'].loc['sum'].loc['ROT ']],                      
                                   'Total ordered quantity':[ self.SML_table1.loc['SML'].loc['sum'].loc['Total ordered quantity'] ,
                                                             self.SML_table2.loc['SML'].loc['sum'].loc['Total ordered quantity'], 
                                                             self.Avery_table1.loc['Avery'].loc['sum'].loc['Total ordered quantity'],  
                                                             self.Avery_table2.loc['Avery'].loc['sum'].loc['Total ordered quantity'], 
                                                             self.CheckPoint_table.loc['CheckPoint'].loc['sum'].loc['Total ordered quantity']]})
        
        self.date = datetime.datetime.now().strftime('%Y-%m-%d')  # 获取当下日期 格式为年-月-日
        self.filename = 'UPS-' + self.date + '.xls'  # 将以上数据保存在名为 xx-xx-xx 后缀为xls的文档里
#        workbook.save(self.filename)
        
        self.data.to_excel(self.filename)
        

 #       sheet = xlrd.open_workbook(r'C:\Users\Administrator\Downloads\t_April_2021.xlsx')
        sheet = xlrd.open_workbook(self.filename)
        myworkbook = copy(sheet)
        worksheet = myworkbook.get_sheet(0)
        worksheet.write(0, 4, 'POT%')
        worksheet.write(0, 5, 'ROT%')
        worksheet.write(1,0 , 'SML1')
        worksheet.write(2,0, 'SML2')
        worksheet.write(3,0 , 'Avery1')
        worksheet.write(4,0, 'Avery2')
        worksheet.write(5,0 , 'CheckPoint%')
        
        table = sheet.sheets()[0]
        for i in range(1,6):
            val = table.cell(i,1).value/table.cell(i,3).value
            worksheet.write(i, 4, val,self.style_percent)
            val = table.cell(i,2).value/table.cell(i,3).value
            worksheet.write(i, 5, val,self.style_percent)
        
        self.filename = 'UPS-' + self.date + 'result.xls'
        myworkbook.save(self.filename) #r'C:\Users\Administrator\Downloads\tt_April_2021.xls')
    
if __name__ == '__main__':  # 程序的入口

    app = QApplication(sys.argv)
    progress = QProgressDialog()
    progress.reject()
    print("1")
    win = UsingTest()
    print("2")
    win.show()
    sys.exit(app.exec_())